const token = '';
// const baseUrl = 'https://www.ayznscm.com';
// const baseUrl = 'http://192.168.31.228:81';
const baseUrl = 'https://www.ayznscm.com';//线上
const newTime = false;
// const baseUrl = 'http://192.168.1.115:81';//线下
// const baseUrl = 'http://192.168.1.110';https://www.ayznscm.com
const userMessage = {};
export default {
    token,
    userMessage,
    baseUrl,
    newTime
}